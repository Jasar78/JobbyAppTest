package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class LoginPage {
    By loginAppLogoLocator = By.className("login-website-logo");
    By labelsLocator = By.className("input-label");
    By usernameInputLocator = By.id("userNameInput");
    By passwordInputLocator = By.id("passwordInput");
    By loginButtonLocator = By.className("login-button");
    By errorMessageLocator = By.className("error-message");

    WebDriver driver;
    WebDriverWait wait;


    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public WebElement findLoginAppLogo() {
        return driver.findElement(loginAppLogoLocator);
    }

    public String getLabelTextAt(int index) {
        return driver.findElements(labelsLocator).get(index).getText();
    }

    public void enterUsername(String username){
        driver.findElement(usernameInputLocator).sendKeys(username);
    }

    public void enterPassword(String password){
        driver.findElement(passwordInputLocator).sendKeys(password);
    }

    public void clickOnLoginButton(){
        driver.findElement(loginButtonLocator).click();
    }

    public void loginToApplication(String username, String password){
        enterUsername(username);
        enterPassword(password);
        clickOnLoginButton();
    }

    public String getErrorMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessageLocator)).getText();
    }
}