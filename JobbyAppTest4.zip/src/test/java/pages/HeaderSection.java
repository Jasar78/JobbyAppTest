package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HeaderSection {
    By applogoLocator = By.cssSelector("div[class $= large-container] img.website-logo");
    By applogoLinkLocator = By.cssSelector("div[class $= large-container]>a");
    By navHomeLinkLocator = By.linkText("Home");
    By navJobsLinkLocator = By.linkText("Jobs");
    By logoutButtonLocator = By.className("logout-desktop-btn");

    WebDriver driver;

    public HeaderSection(WebDriver driver) {
        this.driver = driver;
    }

    public WebElement findAppLogo() {
        return driver.findElement(applogoLocator);
    }

    public void clickOnAppLogo() {
        driver.findElement(applogoLinkLocator).click();
    }

    public void clickOnNavHomeLink() {
        driver.findElement(navHomeLinkLocator).click();
    }

    public void clickOnNavJobsLink() {
        driver.findElement(navJobsLinkLocator).click();
    }

    public void clickOnLogoutButton(){
        driver.findElement(logoutButtonLocator).click();
    }

    public void logout() {
        clickOnLogoutButton();
        driver.switchTo().alert().accept();
    }
}