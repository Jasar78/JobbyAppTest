package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class JobsPage {
    By profileImageLocator = By.className("profile-img");
    By profileNameLocator = By.className("profile-name");
    By shortBioLocator = By.className("short-bio");

    By jobsListItemsLocator = By.className("link-item");

    By searchInputFieldLocator = By.cssSelector("div[class ^='desktop'] input.search-input");
    By searchButtonLocator = By.cssSelector("div[class ^='desktop'] button.search-button");

    By jobsNotFoundImageLocator = By.className("jobs-not-found-img");
    By jobsNotFoundHeadingLocator = By.className("jobs-not-found-heading");
    By jobsNotFoundDescriptionLocator = By.className("jobs-not-found-description");

    By searchResultLocator = By.className("results-text");

    WebDriver driver;
    WebDriverWait wait;

    public JobsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public WebElement findProfileImage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(profileImageLocator));
    }

    public String getProfileName() {
        return driver.findElement(profileNameLocator).getText();
    }

    public String getShortBio() {
        return driver.findElement(shortBioLocator).getText();
    }

    public int getJobsCount() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(jobsListItemsLocator));
        return driver.findElements(jobsListItemsLocator).size();
    }

    public void enterSearchText(String searchtext) {
        driver.findElement(searchInputFieldLocator).sendKeys(searchtext);
    }

    public void clickSearchButton() {
        driver.findElement(searchButtonLocator).click();
    }

    public void search(String searchText) {
        enterSearchText(searchText);
        clickSearchButton();
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchResultLocator));
    }

    public WebElement findJobsNotFoundImage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(jobsNotFoundImageLocator));
    }

    public String getJobsNotFoundHeading() {
        return driver.findElement(jobsNotFoundHeadingLocator).getText();
    }

    public String getJobsNotFoundDescription() {
        return driver.findElement(jobsNotFoundDescriptionLocator).getText();
    }
}
