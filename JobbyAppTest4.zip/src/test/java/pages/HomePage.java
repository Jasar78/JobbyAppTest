package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class HomePage {
    By headingLocator = By.className("home-heading");
    By descriptionLocator = By.className("home-description");
    By findJobsButtonLocator = By.className("find-jobs-button");

    WebDriver driver;
    WebDriverWait wait;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public String getHeadingText() {
        return driver.findElement(headingLocator).getText();
    }

    public String getDescriptionText() {
        return driver.findElement(descriptionLocator).getText();
    }

    public void clickOnFindJobsButton(){
        driver.findElement(findJobsButtonLocator).click();
    }
}